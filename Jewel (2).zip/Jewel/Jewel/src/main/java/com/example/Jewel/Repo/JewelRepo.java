package com.example.Jewel.Repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Jewel.TO.ItemTo;

public interface JewelRepo extends JpaRepository<ItemTo, Long> {
	
	Optional<ItemTo> findByWeight(double d);

}
