package com.example.Jewel.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Jewel.Repo.JewelRepo;
import com.example.Jewel.TO.ItemTo;




@Service
public class JewelService {

	@Autowired
	private JewelRepo jewelRepo;

	
	//---------------------------------------------------------------
	
	public ResponseEntity<List<ItemTo>> getAllItems()
	{
		try
		{
			List<ItemTo> itemList = new ArrayList<>();
			jewelRepo.findAll().forEach(itemList::add);
			
			if(itemList.isEmpty())
			{
				return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
			}
			return new ResponseEntity<>(itemList, HttpStatus.OK);
		}
			
			catch (Exception ex)
			{
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		
	
	}
	
	//--------------------------------------------------------------------------------------------
	public ResponseEntity<ItemTo> getItemsById(@PathVariable Long id)
	{
		Optional<ItemTo> itemData = jewelRepo.findById(id);
		try
		{
			if(itemData.isPresent())
			{
				return new ResponseEntity<>(itemData.get(),HttpStatus.OK);
			}
			
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//-----------------------------------------------------------------------------
	
	public ResponseEntity<ItemTo> getItemByWeight(@PathVariable Float weight)
	{
		Optional<ItemTo> itemData = jewelRepo.findByWeight(weight);
		try
		{
			if(itemData.isPresent())
			{
				return new ResponseEntity<>(itemData.get(),HttpStatus.OK);
			}
			
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		catch(Exception ex)
		{
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//--------------------------------------------------------------------------------
	public void getItemByCarat()
	{
		
	}
	
	//-------------------------------------------------------------------------------
	
	public ResponseEntity<ItemTo> addItem(@RequestBody ItemTo item)
	{
		ItemTo itemObj = jewelRepo.save(item);
		return new ResponseEntity<>(itemObj,HttpStatus.OK);
	}
	
	//---------------------------------------------------------------------------------
	
	public ResponseEntity<ItemTo> updateItemById(@PathVariable Long id, @RequestBody ItemTo newItem)
	{
		Optional<ItemTo> oldItem = jewelRepo.findById(id);
		if(oldItem.isPresent())
		{
			ItemTo updatedItem = oldItem.get();
			updatedItem.setName(newItem.getName());
			updatedItem.setCarat(newItem.getCarat());
			updatedItem.setMetal(newItem.getMetal());
			updatedItem.setWeight(newItem.getWeight());
			
			ItemTo itemObj = jewelRepo.save(updatedItem);
			return new ResponseEntity<>(itemObj, HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	//------------------------------------------------------------------------------
	
	public String deleteItem(@PathVariable Long id)
	{
		Optional<ItemTo> itemObj = jewelRepo.findById(id);
		
		if(itemObj.isPresent())
		{
			jewelRepo.deleteById(id);
			return "Item deleted";
		}
		else
		{
			return "item not found";
		}
	}
	
	
}
