package com.example.Jewel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JewelApplication {

	public static void main(String[] args) {
		SpringApplication.run(JewelApplication.class, args);
	}

}
