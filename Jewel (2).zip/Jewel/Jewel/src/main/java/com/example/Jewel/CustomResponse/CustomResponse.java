package com.example.Jewel.CustomResponse;

import java.util.List;

import com.example.Jewel.TO.ItemTo;

public class CustomResponse {
    private String message;
    private List<ItemTo> items;

    public CustomResponse(String message, List<ItemTo> items) {
        this.message = message;
        this.items = items;
    }

    // Getters and Setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<ItemTo> getItems() {
        return items;
    }

    public void setItems(List<ItemTo> items) {
        this.items = items;
    }
}
