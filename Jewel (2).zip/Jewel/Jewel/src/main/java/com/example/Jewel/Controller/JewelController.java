package com.example.Jewel.Controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Jewel.CustomResponse.CustomResponse;
import com.example.Jewel.Service.JewelService;
import com.example.Jewel.TO.ItemTo;

@RestController
public class JewelController {
	
	@Autowired
	private JewelService jewelService;
	
	
	//----------------Get All Items------------------------------------------------------
	@GetMapping("/getAllItems")
	public List<ItemTo> getAllItems()
	{
		List<ItemTo> emptyList = null; 
		List<ItemTo> itemList = (List<ItemTo>) jewelService.getAllItems();
		
		if(itemList.isEmpty())
		{
			return null;
		}
		return itemList;
		
		
	}
	
	//---------------------- ADD Item ----------------------------------------------------
	@PostMapping("/addItem")
	public String addItem(@RequestBody ItemTo item)
	{
		try
		{
		jewelService.addItem(item);
		return "Item added successfully";
		}
		catch(Exception ex)
		{
			return "Something wrong";
		}
	}
	
	
	//----------------------------Get Item by ID --------------------------------------------
	@GetMapping("/getItembyId/{id}")
	public ResponseEntity<CustomResponse> getItemById(@PathVariable Long id) {
        ResponseEntity<ItemTo> itemResponse = jewelService.getItemsById(id);
        
        if (itemResponse.getStatusCode() == HttpStatus.OK) {
            List<ItemTo> itemList = Collections.singletonList(itemResponse.getBody());
            CustomResponse response = new CustomResponse("Found", itemList);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else if (itemResponse.getStatusCode() == HttpStatus.NOT_FOUND) {
            CustomResponse response = new CustomResponse("Empty List", Collections.emptyList());
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	//-----------------------------Get Item by Weight----------------------------------------
	@GetMapping("/getItembyWeight/{weight}")
	public ResponseEntity<CustomResponse> getItemByWeight(@PathVariable Float weight) {
        ResponseEntity<ItemTo> itemResponse = jewelService.getItemByWeight(weight);
        
        if (itemResponse.getStatusCode() == HttpStatus.OK) {
            CustomResponse response = new CustomResponse("Found", List.of(itemResponse.getBody()));
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else if (itemResponse.getStatusCode() == HttpStatus.NOT_FOUND) {
            CustomResponse response = new CustomResponse("Empty List", List.of());
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	//--------------------------Update Item By ID ----------------------------------------
	
	@PostMapping("/updateItem/{id}")
	public String updateitem(@PathVariable Long id, @RequestBody ItemTo item)
	{
		try
		{
			jewelService.updateItemById(id, item);
			return "Item Updated SuccessFully";
		}
		catch(Exception ex)
		{
			return "Kuch toh gadbad hai";
		}
	}
	
	//-------------Delete Items ----------------------------------------------------------
	
	@DeleteMapping("/deleteItem/{id}")
	public String deleteItem(@PathVariable Long id)
	{
		try
		{
			jewelService.deleteItem(id);
			return "Item deleted";
		}
		catch(Exception ex)
		{
			return "Kuch toh gadbad hai";
		}
	}
	
	

}
